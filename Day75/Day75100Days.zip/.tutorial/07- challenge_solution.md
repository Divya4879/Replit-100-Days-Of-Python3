# Solution (No Peeking!)
![](https://www.youtube.com/watch?v=qXu2pUhEcz4)
<details> <summary> 👀 Answer </summary>

Check out my solution in [this repl](https://replit.com/@replit/Day-075-Solution?v=1).


</details>

- Join our [100 Days Community](https://replit.com/100-days-help)
- Join our [Discord](https://replit.com/discord)
- Want [live support?](https://replit.com/replit-101)


By the way, since you are 75% of the way done, we are curious to know if you would like a certificate to show off all your new skills when you make it to the end. Let us know [here](https://forms.gle/HvHWJj1MQ4VdyGmg8).